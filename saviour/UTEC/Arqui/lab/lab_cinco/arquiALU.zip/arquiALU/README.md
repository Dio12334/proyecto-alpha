# Draft del Proyecto para Arqui 2020-1
Abril Vento && Diego Paredes

## Contenidos
* Lab 05: ALU | due 12/06 | done
* Lab 06: MIPS | due 28/06 | done
* Lab 07: Single Cycle Processor @Project part 1 | due 21/07 | done
* Lab 08: Multi Cycle Processor Controller @Project part 2 | due 21/07 | done
* Lab 09: Multi Cycle Processor Datapath @Project part 3 | due 21/07
