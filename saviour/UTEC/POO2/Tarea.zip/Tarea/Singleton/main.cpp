#include"singleton.h"

int main(){
  
  return 0;
}
