#ifndef SINGLETON_H
#define SINGLETON_H

class Singleton{

};

#endif
