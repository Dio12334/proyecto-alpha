#ifndef STATE_H
#define STATE_H

class State{
  public:
      virtual void do_this() const = 0;
};


#endif

